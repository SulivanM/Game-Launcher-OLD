@extends('layouts.app') @section('content')
<link href="{{ asset('css/app.css') }}" rel="stylesheet">
<div class="container">
  <aside>
    <div class="top">
      <div class="logo">
        <img class="logo" src="{{ asset('images/logo.svg') }}" alt="Logo" href="/" />
        <h2>Moba <span class="danger">Chocolate</span>
        </h2>
      </div>
      <div class="close" id="close-btn">
        <span class="material-symbols-sharp">close</span>
      </div>
    </div>
    <div class="sidebar">
      <!-- <div> -->
      <button class="play-button rounded-corners"> Play <span class="vector-icon">
          <i class="fa fa-play-circle"></i>
        </span>
      </button>
      <!-- </div>    -->
      <a href="home" class="active">
        <span class="material-symbols-sharp">house</span>
        <h1 class="h1">Home</h1>
      </a>
      <a href="#">
        <span class="material-symbols-sharp">search</span>
        <h1 class="h1">Search</h1>
      </a>
      <a href="friends">
        <span class="material-symbols-sharp">person_add</span>
        <h1 class="h1">Friends</h1>
      </a>
      <a href="games">
        <span class="material-symbols-sharp">gamepad</span>
        <h1 class="h1">Games</h1>
      </a>
	  <a href="collections">
        <span class="material-symbols-sharp">gamepad</span>
        <h1 class="h1">Collections</h1>
      </a>
      <a href="notifications">
        <span class="material-symbols-sharp">mail_outline</span>
        <h1 class="h1">Notifications</h1>
        <circle class="message-count">2</circle>
      </a>
      <a href="trophy">
        <span class="material-symbols-sharp">star</span>
        <h1 class="h1">Trophy</h1>
      </a>
      <a href="tchat">
        <span class="material-symbols-sharp">person</span>
        <h1 class="h1">Tchat</h1>
      </a>
      <a href="streams">
        <span class="material-symbols-sharp">camera</span>
        <h1 class="h1">Streams</h1>
      </a>
      <a href="balance">
        <span class="material-symbols-sharp">add</span>
        <h1 class="h1">Balance</h1>
      </a>
      <a href="suggests">
        <span class="material-symbols-sharp">add</span>
        <h1 class="h1">Suggestions</h1>
      </a>
      <div class="icons">
		<i class="fa-brands fa-twitch"></i>
        <i class="fa-brands fa-twitter"></i>
        <i class="fa-brands fa-instagram"></i>
		<i class="fa-brands fa-facebook"></i>
        <i class="fa-brands fa-youtube"></i>
        <i class="fa-brands fa-discord"></i>
      </div>
      <a href="#">
        <span class="material-symbols-sharp">logout</span>
        <h1 class="h1">Support</h1>
      </a>
      <a href="#">
        <span class="material-symbols-sharp">settings</span>
        <h1 class="h1">Settings</h1>
      </a>
      <a href="{{ route('logout') }}" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
        <span class="material-symbols-sharp">logout</span>
        <h1 class="h1">{{ ('Logout') }}</h1>
      </a>
      <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none"> @csrf </form>
    </div>
  </aside>
  <main>
    <div class="banner" id="particles-js">
     @include('partials.navbar')
      <div class="banner-text">
        <h1>Many Games </h1>
        <br>
        <h1>
	      <span style="color:#3c454c;"> Coming </span>
          <span class="primary">SOON</span>
        </h1>
        <p style="color: #fdfdfd;">More Details <span style="color: white;">></span>
        </p>
      </div>
      <div class="bottom">
        <a href="{{ route('profile') }}">
			<div class="profile-photo">
				@if(Auth::user()->profile_image)
					<img src="{{ asset('images/profiles/' . Auth::user()->profile_image) }}" alt="Profile Image">
				@else
					<img src="{{ asset('images/profile-icon.png') }}" alt="Default Profile Image">
				@endif
			</div>
		</a>
        <button type="button" class="strim-btn">Profile</button>
        <button>Challenge</button>
        <p>
          <b class="mx-3">Team: NONE</b>
          <i class="fa fa-pencil"></i>
        </p>
      </div>
      <div class="dfjsac">
        <div class="links">
          <a href="#" style="color:white"> Basic Information</a>
          <a href="#">Statistics</a>
          <a href="#">Team</a>
          <a href="#">Acheivements</a>
          <a href="#">Friends</a>
        </div>
        <div class="social-links">
          <a href="#">
          <i class="fa-brands fa-twitch"></i>
		  </a>
		  <a href="#">
          <i class="fa-brands fa-twitter"></i>
		  </a>
		  <a href="#">
          <i class="fa-brands fa-instagram"></i>
		  </a>
		  <a href="#">
		  <i class="fa-brands fa-facebook"></i>
	      </a>
		  <a href="#">
          <i class="fa-brands fa-youtube"></i>
	      </a>
		  <a href="#">
          <i class="fa-brands fa-discord"></i>
          </a>
        </div>
      </div>
      <div class="line"></div>
    </div>
    <div class="slider">
    <div class="owl-slider">
        <div id="carousel" class="owl-carousel">
            @foreach ($games as $game)
			<div class="item">
				<div class="tile-1 slider-tile">
					<img src="{{ asset('images/games/' . $game->game_image) }}" alt="{{ $game->title }}" class="game-image">
					<div class="first-txt">
						<h2>{{ $game->title }}</h2>
						<h1>{{ $game->subtitle }} <span class="primary">!</span></h1>
						<p>{{ $game->description }}</p>
						<div class="button">
							<a href="{{ $game->getGameRoute() }}" class="strim-btn">PLAY NOW</a>
						</div>
					</div>
				</div>
			</div>
			@endforeach
        </div>
    </div>
	</div>

    <div class="statistics">
      <div class="statistics-heading">
        <h1> Statistics </h1>
        <!--<div>
          <img src="{{ asset('images/app/pro-img.png') }}">
          <img src="{{ asset('images/app/pro-img.png') }}">
          <img src="{{ asset('images/app/pro-img.png') }}">
          <img src="{{ asset('images/app/pro-img.png') }}">
          <img src="{{ asset('images/app/pro-img.png') }}">
        </div>-->
      </div>
      <div class="data">
        <div>
          <img src="{{ asset('images/app/stats.svg') }}" class="shield-img">
        </div>
        <div>
          <p>
            <span class="text_mutted">Nickname</span> {{ Auth::user()->name }}
          </p>
          <p>
            <span class="text_mutted">Real Name </span>
            @if (!is_null($user->prenom) || !is_null($user->nom))
                {{ $user->prenom ?? 'NA' }} {{ $user->nom ?? 'NA' }}
            @else
                NA
            @endif
		  </p>
          <p class="flag-img">
            <span class="text_mutted">Nationality </span>
			@if (!is_null($user->language))
                {{ $user->language ?? 'NA' }}
            @else
                NA
            @endif
            <img src="{{ asset('images/app/flag.png') }}">
          </p>
        </div>
        <div>
          <p>
            <span class="text_mutted">Level</span> NA
          </p>
          <p>
            <span class="text_mutted">Team</span> NA
          </p>
          <p>
            <span class="text_mutted">Best Friend</span> NA
          </p>
        </div>
        <div>
          <p>
            <span class="text_mutted">Win Rate</span> NA%
          </p>
          <p>
            <span class="text_mutted">Rating Total </span> NA
          </p>
          <p>
            <span class="text_mutted">Position</span> NA
          </p>
        </div>
        <div>
          <div class="price-tag">
            <div class="icon">
              <i class="fas fa-trophy trophy-gold"></i>
            </div>
            <div>
              <p>Prize pool <br>
                <span class="text_mutted">NA $</span>
              </p>
            </div>
          </div>
          <div class="price-tag">
            <div class="icon">
              <i class="fas fa-trophy trophy-gold"></i>
            </div>
            <div>
              <p>Prize pool <br>
                <span class="text_mutted">NA $</span>
              </p>
            </div>
          </div>
        </div>
        <div>
          <div class="price-tag">
            <div class="icon">
              <i class="fas fa-trophy trophy-sliver"></i>
            </div>
            <div>
              <p>Prize pool <br>
                <span class="text_mutted">NA $</span>
              </p>
            </div>
          </div>
          <div class="price-tag">
            <div class="icon">
              <i class="fas fa-trophy trophy-sliver"></i>
            </div>
            <div>
              <p>Prize pool <br>
                <span class="text_mutted">NA $</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
</div>
<script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
<script src="{{ asset('js/particules-home.js') }}"></script>
<script src="{{ asset('js/index.js') }}"></script>
<script src="{{ asset('js/carousel.js') }}"></script>
@endsection