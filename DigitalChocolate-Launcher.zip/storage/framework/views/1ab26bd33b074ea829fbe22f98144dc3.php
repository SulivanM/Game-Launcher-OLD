<?php $__env->startSection('content'); ?>
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
	
	<?php echo $__env->make('preloader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <header class="header">
        <div class="logo">
            <a href="/">
                <img class="logo-img" src="<?php echo e(asset('images/logo.svg')); ?>" alt="Logo">
            </a>
        </div>
        <nav class="nav-links">
            <?php if(Route::has('login')): ?>
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(url('/home')); ?>">Home</a>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>">Log in</a>
                    <?php if(Route::has('register')): ?>
                        <a href="<?php echo e(route('register')); ?>">Register</a>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        </nav>
    </header>

	<div class="title-main">
		<h2>WELCOME TO MOBACHOCOLATE LAUNCHER !</h2>
	</div>

	<div class="slider">
    <div class="owl-slider">
        <div id="carousel" class="owl-carousel">
            <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
                <div class="slider-tile">
					<img src="<?php echo e(asset('images/games/' . $game->game_image)); ?>" alt="<?php echo e($game->title); ?>" class="game-image">
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
	</div>

	<script src="<?php echo e(asset('js/preloader.js')); ?>"></script>
	<script src="<?php echo e(asset('js/carousel.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/digitalchocolate.online/launcher.digitalchocolate.online/resources/views/welcome.blade.php ENDPATH**/ ?>