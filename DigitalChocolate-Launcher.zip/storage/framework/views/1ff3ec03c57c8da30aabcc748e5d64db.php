 <?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
<form class="connect-form" method="POST" action="<?php echo e(route('update.email')); ?>">
   <a href="/">
      <img class="logo" src="<?php echo e(asset('images/logo.svg')); ?>" alt="Logo">
   </a> <?php echo csrf_field(); ?>
   <h1><?php echo e(__('Add Your Email')); ?></h1>
   <input type="email" class="form-control" id="email" name="email" placeholder="Enter email">
   <button type="submit" class="btn btn-primary">Submit</button>
   <div class="additional-buttons">
      <button type=button class="register-button" onclick="window.location.href = '<?php echo e(url('/')); ?>'">
         <i class="fas fa-user-plus"></i> Home </button>
   </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/digitalchocolate.online/launcher.digitalchocolate.online/resources/views/popup.blade.php ENDPATH**/ ?>