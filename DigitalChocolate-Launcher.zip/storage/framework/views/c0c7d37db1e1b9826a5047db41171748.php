 <?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
<form class="connect-form" method="POST" action="<?php echo e(route('register')); ?>">
	<a href="/">
		<img class="logo" src="<?php echo e(asset('images/logo.svg')); ?>" alt="Logo">
	</a>
	<?php echo csrf_field(); ?>
	<h1><?php echo e(__('Register')); ?></h1>
	<input id="name" type="text" class="form-control bg-dark text-white <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name"
		value="<?php echo e(old('name')); ?>" required placeholder="<?php echo e(__('Name')); ?>" autocomplete="name" autofocus />
	<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	<script>
		Swal.fire({
			icon: 'error',
			title: 'Error',
			text: <?php echo json_encode($message, 15, 512) ?>,
		});
	</script>
	<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	<input id="email" type="email" class="form-control bg-dark text-white <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
		name="email" value="<?php echo e(old('email')); ?>" required placeholder="<?php echo e(__('Email Address')); ?>" autocomplete="email" />
	<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	<script>
		Swal.fire({
			icon: 'error',
			title: 'Error',
			text: <?php echo json_encode($message, 15, 512) ?>,
		});
	</script>
	<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	<input id="password" type="password" class="form-control bg-dark text-white <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
		name="password" required placeholder="<?php echo e(__('Password')); ?>" autocomplete="new-password" />
	<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	<script>
		Swal.fire({
			icon: 'error',
			title: 'Error',
			text: <?php echo json_encode($message, 15, 512) ?>,
		});
	</script>
	<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	<input id="password-confirm" type="password" class="form-control bg-dark text-white" name="password_confirmation"
		required placeholder="<?php echo e(__('Password')); ?>" autocomplete="new-password" />
	<button type="submit"><?php echo e(__('Register')); ?></button>
	<p class="or">OR</p>
	<div class="additional-buttons">
		<button type=button class="register-button" onclick="window.location.href = '<?php echo e(url('login')); ?>'"><i
				class="fas fa-user-plus"></i> Login</button>
		<button type=button class="forgot-password-button"
			onclick="window.location.href = '<?php echo e(url('password/reset')); ?>'"><i class="fas fa-key"></i> Forgot
			Password</button>
	</div>
</form>
<div class="social-buttons">
	<button class="social-button twitter" onclick="window.location.href = '<?php echo e(url('auth/twitter')); ?>'">
		<i class="fa-brands fa-x-twitter"></i> Register With X</button>
	<button class="social-button github" onclick="window.location.href = '<?php echo e(url('auth/github')); ?>'">
		<i class="fab fa-github"></i> Register With GitHub</button>
	<button class="social-button discord" onclick="window.location.href = '<?php echo e(url('auth/discord')); ?>'">
		<i class="fab fa-discord"></i> Register With Discord</button>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/digitalchocolate.online/launcher.digitalchocolate.online/resources/views/auth/register.blade.php ENDPATH**/ ?>