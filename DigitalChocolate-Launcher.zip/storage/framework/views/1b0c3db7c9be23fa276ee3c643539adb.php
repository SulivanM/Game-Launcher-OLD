<div class="search__container">
  <input class="search__input" type="text" id="search-input" placeholder="Search..">
  <i class="fa-regular fa-bell"></i>
  <i class="fa-solid fa-message">
    <sup>0 </sup>
  </i>
  <div class="right">
    <div class="top">
      <button id="menu-btn">
        <span class="material-symbols-sharp">menu</span>
      </button>
      <p>
        <b>Theme</b>
      </p>
      <div class="theme-toggler">
        <span class="material-symbols-sharp">light_mode</span>
        <span class="material-symbols-sharp active">dark_mode</span>
      </div>
      <div class="profile">
        <div class="info">
          <p><a href="<?php echo e(route('profile')); ?>"><?php echo e(Auth::user()->name); ?></a></p>
        </div>
        <a href="<?php echo e(route('profile')); ?>">
			<div class="profile-photo">
				<?php if(Auth::user()->profile_image): ?>
					<img src="<?php echo e(asset('images/profiles/' . Auth::user()->profile_image)); ?>" alt="Profile Image">
				<?php else: ?>
					<img src="<?php echo e(asset('images/profile-icon.png')); ?>" alt="Default Profile Image">
				<?php endif; ?>
			</div>
		</a>
      </div>
	  <a href="<?php echo e(route('settings.show')); ?>">
		  <i class="fa-solid fa-gear"></i>
	  </a>
    </div>
  </div>
</div><?php /**PATH /var/www/vhosts/digitalchocolate.online/launcher.digitalchocolate.online/resources/views/partials/navbar.blade.php ENDPATH**/ ?>