 <?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
<form class="connect-form" method="POST" action="<?php echo e(route('login')); ?>">
   <a href="/">
      <img class="logo" src="<?php echo e(asset('images/logo.svg')); ?>" alt="Logo">
   </a> <?php echo csrf_field(); ?>
   <h1><?php echo e(__('Reset Password')); ?></h1>
   <input id="email" type="email" class="form-control bg-dark text-white <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
      name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus> <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span
      class="invalid-feedback" role="alert">
      <strong><?php echo e($message); ?></strong>
   </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <button type="submit"><?php echo e(__('Send Password Link')); ?></button>
   <p class="or">OR</p>
   <div class="additional-buttons">
      <button type=button class="register-button" onclick="window.location.href = '<?php echo e(url('/')); ?>'">
         <i class="fas fa-user-plus"></i> Home </button>
   </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/digitalchocolate.online/launcher.digitalchocolate.online/resources/views/auth/passwords/email.blade.php ENDPATH**/ ?>